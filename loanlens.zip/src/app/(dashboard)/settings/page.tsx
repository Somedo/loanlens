import { createClient } from '@/lib/supabase/server'
import CompanySettingsForm from '@/components/settings/CompanySettingsForm'

export default async function SettingsPage() {
  const supabase = await createClient()
  
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Get the user's company data
  const { data: userData } = await supabase
    .from('users')
    .select('*, company:companies(*)')
    .eq('id', user?.id)
    .single()

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Company Settings</h1>
        <p className="mt-2 text-sm text-gray-600">
          Manage your company profile, addresses, and regulatory information.
        </p>
      </div>

      <CompanySettingsForm company={userData?.company} />
    </div>
  )
}